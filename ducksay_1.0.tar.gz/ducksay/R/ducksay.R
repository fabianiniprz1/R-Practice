ducksay <- function(phrase = "hello, world"){
  paste(
  phrase, 
  ">(~ )",
  " (____)",
  sep = "\n"
)
}